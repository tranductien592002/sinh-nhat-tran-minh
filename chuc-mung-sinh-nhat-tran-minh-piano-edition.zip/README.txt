
Piano Edition — Happy Birthday Trần Minh
Files:
- index.html : main page (open in browser to preview)
- favicon.png : decorative icon

To publish quickly:
1) Unzip and open index.html locally to test.
2) Drag the unzipped folder into https://app.netlify.com/drop to get a public link.
3) If music doesn't autoplay, click "Mở thiệp & Bật nhạc".
